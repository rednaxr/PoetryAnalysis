const words = require('..')

words.length
// => 133779

words.phenomenon
// => 'F AH0 N AA1 M AH0 N AA2 N'
words.zygote
// => 'Z AY1 G OW0 T'
